<?php $page="future"; ?>

<?php 


	
	include("header.php"); 

?>

	<div id ="sidebar"> <!-- sidebar contents-->

		<?php include("sidebar.php") ?> 

	</div><!--end of sidebar-->


	<div id="content">
<p>This is the Future page!</p>
			
	</div><!--end of contents-->






<div id="footer">
<?php include("footer.php"); ?>
</div><!--end of footer-->
</body>








</html>
