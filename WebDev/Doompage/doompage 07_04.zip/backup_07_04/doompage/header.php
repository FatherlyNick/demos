<html>

<head>
<link id="pagestyle" rel ="stylesheet" type="text/css" href="style.css">

<link rel="shortcut icon" href="icon.ico" />
<script src="stylechange.js" type="text/javascript"></script>
 


<title>:: DOOM ::</title>



</head>


<body>



	<div id="header"> <a href="doom.php"><img src="img/header.jpg" alt = "Doom logo"/></a> 
		<div id="specCSS"><button onClick="swapStyleSheet('style');">Default Style</button><!--DEFAULT STYLE-->
				<button onClick="swapStyleSheet('largefont');">Large Font</button><!--LARGE FONT STYLE-->
				<button onClick="swapStyleSheet('highcontrast');">High Contrast</button><!-HIGH CONTRAST STYLE-->
		
		</div><!--end of specCSS-->
		
	</div><!--end of header-->


<div id="descr"> <h2>Welcome to Doom</h2>
		
	<p>Here you can read about Doom's past present and its future</p>

</div><!--end of welcome-->


<div id="nav">

<?php include("nav.html");?>


</div><!--end of navigation bar-->