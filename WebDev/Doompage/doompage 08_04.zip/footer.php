<hr>
<footer> &copy someone 2013 </footer>
</body>
</html>