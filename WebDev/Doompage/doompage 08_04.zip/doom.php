<?php $page = "home"; ?>

<?php 
	

	include("header.php"); 

	

?>

			
	

	<div id ="sidebar"> <!-- sidebar contents-->

		<?php include("sidebar.php") ?> 

	</div><!--end of sidebar-->


	<div id="content">

		<p> From Demons to BFGs', all things Doom in one place! From Demons to BFGs', all things Doom in one place! From Demons to BFGs', all things Doom in one place! From Demons to BFGs', all things Doom in one place! From Demons to BFGs', all things Doom in one place! From Demons to BFGs', all things Doom in one place! From Demons to BFGs', all things Doom in one place! From Demons to BFGs', all things Doom in one place! From Demons to BFGs', all things Doom in one place! From Demons to BFGs', all things Doom in one place! From Demons to BFGs', all things Doom in one place! From Demons to BFGs', all things Doom in one place! From Demons to BFGs', all things Doom in one place! From Demons to BFGs', all things Doom in one place! From Demons to BFGs', all things Doom in one place! From Demons to BFGs', all things Doom in one place! From Demons to BFGs', all things Doom in one place! From Demons to BFGs', all things Doom in one place! From Demons to BFGs', all things Doom in one place! From Demons to BFGs', all things Doom in one place! From Demons to BFGs', all things Doom in one place! From Demons to BFGs', all things Doom in one place! From Demons to BFGs', all things Doom in one place! From Demons to BFGs', all things Doom in one place! From Demons to BFGs', all things Doom in one place! From Demons to BFGs', all things Doom in one place! </p>
			
	</div><!--end of contents-->






<div id="footer">
<?php include("footer.php"); ?>
</div><!--end of footer-->

</body>








</html>
