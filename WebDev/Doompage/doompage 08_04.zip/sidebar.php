
	<img src="img/script-quick-reference.png" alt = "Quick links"/><br>

		
	<a class="newslink"><a href="news.php"><img src="img/news.png" alt="News link"/></a><br>
 	
	<a href="http://www.facebook.com/idsoftware"><img src="img/top-requests-facebook.png" alt="idsoftware on Facebook"/></a>

	<a href="http://www.twitter.com/idsoftware"><img src="img/top-requests-twitter.png" alt="idsoftware on Twitter"/></a>

