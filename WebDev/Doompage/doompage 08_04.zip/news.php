<?php $page = "news"; ?>

<?php 
	

	include("header.php"); 

	

?>

			
	

	<div id ="sidebar"> <!-- sidebar contents-->

		<?php include("sidebar.php") ?> 

	</div><!--end of sidebar-->


	<div id="content">
<p>This is the news page! There should be some databses interactivity here for people to post and discuss things.</p>
	</div><!--end of contents-->






<div id="footer">
<?php include("footer.php"); ?>
</div><!--end of footer-->

</body>








</html>
